
import { test, expect } from '@playwright/test';

test('Trace Viewer туршилт - зориуд алдаа гаргах', async ({ page }) => {
    await page.goto('https://www.saucedemo.com');

    await page.getByPlaceholder('Username').fill('standard_user');
    await page.getByPlaceholder('Password').fill('secret_sauce');

    await page.getByRole('button', { name: 'Login' }).click();

    // Trace Viewer дээр алдааг ажиглахын тулд зориуд буруу утга шалгана.
    await expect(page.getByText('This is an intentional error')).toBeVisible();
});
